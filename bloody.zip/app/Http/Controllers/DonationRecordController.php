<?php

namespace App\Http\Controllers;

use App\Models\DonationRecord;
use Illuminate\Http\Request;

class DonationRecordController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DonationRecord $donationRecord)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DonationRecord $donationRecord)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DonationRecord $donationRecord)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DonationRecord $donationRecord)
    {
        //
    }
}
