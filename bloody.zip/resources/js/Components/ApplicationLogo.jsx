
export default function ApplicationLogo(props) {
    return (
        <div className="mx-auto w-40">
            <img src='/img/bloody.svg' />
        </div>
    );
}
